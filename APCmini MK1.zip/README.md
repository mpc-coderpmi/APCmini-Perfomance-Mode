# APC Mini MK1 — V14: rotation-aware exclusive launch and fills

Based on your **hardware-tested working V13**. New functionality is experimental.

## Commands

- **Shift + 6** hold about one second: save the currently playing pattern.
- **Shift + 6** quick press: recall the saved pattern.
- **Shift + 6 + one or more clip pads**: start alternating A/B rotation, 4 bars each.
- **Shift + 6 + scene button 8**: cancel rotation without stopping music.
- **Shift + one or more clip pads**: exclusive launch; **cancels any active rotation** and stops unrelated playing tracks.
- **Shift + 7 + clip pads**: temporary fill; if rotation is on, wait until the end of the **current bar** to start the fill, temporarily pause rotation, then advance to the **next A/B rotation pattern** and keep alternating every four bars. Otherwise original V13 fill behavior.

## Rotation/fill timing

- User selects the fill while current A or B rotation pattern is playing.
- Fill begins on next bar at bar quantization (or immediate if scheduler tick is late).
- The fill runs for the longest selected clip (same behavior as V13).
- Instead of restoring pre-fill clips, resume the **next rotation pattern**, quantized to a bar. Continue 4-bar alternation.
- Existing unselected clips still follow the original fill behavior (normally stop during fill).
- If a clip is unwarped audio, V13's restriction applies.

## Installation

Copy `APC_Mini_Rotation_Memory_v14_MK1` into Ableton User Library's `Remote Scripts` folder. Restart Live, select this as the control surface, and set your APC Mini as input/output.

## Test steps

1. Verify the APC lights and pads work (same initialization as V13).
2. Set A = 3 playing texture clips; Shift+6+3 new clip pads selects B.
3. Allow B to play; Shift+7+fill pad(s). Fill should enter at the next bar, finish its loop, then launch the next pattern and continue 4-bar rotation.
4. During rotation, Shift+pad(s) should cancel rotation and switch exclusively to those clips.
5. Confirm Shift+6+8 still cancels rotation, and Shift+6 tap/hold still recall/save.

**Experimental:** syntax validated, but actual musical timing and hardware feedback require testing in Ableton. Back up V13. Remote Script timing is not sample-accurate and clips relaunch from their beginnings.
