"""Live 12 APC Mini MK1: rotation and one-slot pattern memory.

Built on the same scoped-scene patch as the user's FIRST working version.
"""
from types import MethodType
from APC_mini.APC_mini import APC_mini as StockAPCMini


def _slot_is_actionable(slot):
    return (slot is not None
            and not getattr(slot, 'is_group_slot', False)
            and (slot.has_clip or slot.has_stop_button))


def _scoped_scene_launch(self, value):
    if self._scene is None or self._launch_button is None:
        return
    pressed = value != 0
    momentary = self._launch_button.is_momentary()
    if momentary:
        if pressed:
            slots = [w._clip_slot for w in self._clip_slots
                     if _slot_is_actionable(w._clip_slot)]
            self._scoped_pressed_slots = slots
        else:
            slots = getattr(self, '_scoped_pressed_slots', [])
            self._scoped_pressed_slots = []
        for slot in slots:
            slot.set_fire_button_state(pressed)
    elif pressed:
        for wrapper in self._clip_slots:
            slot = wrapper._clip_slot
            if _slot_is_actionable(slot):
                slot.fire()
    if pressed and self.song().select_on_launch:
        self.song().view.selected_scene = self._scene


# V5: MK1 ONLY. Scene Launch 7 on original APC Mini is MIDI note 88.
# All clip button LEDs stay under the stock APC Mini controller script.
import Live
import math


class PerformanceMixin:
    SHIFT_NOTE = 98
    ROTATION_MODIFIER_NOTE = 87  # Sixth scene button
    STOP_ALL_NOTE = 89  # Eighth scene button
    FILL_MODIFIER_NOTE = 88  # Seventh circular scene button, counted from top.

    def _performance_init(self):
        self._exclusive_shift_down = False
        self._exclusive_consumed_pad_notes = set()
        self._fill_modifier_down = False
        self._fill_modifier_consumed = False
        self._fill_job = None
        self._fill_selected_notes = []
        self._exclusive_selected_notes = []
        self._rotation_modifier_down = False
        self._rotation_modifier_consumed = False
        self._rotation_selected_notes = []
        self._rotation_swallow_stop_release = False
        self._rotation_was_cancelled = False
        self._rotation_job = None
        self._rotation_fill_pending = None
        # Pattern memory uses Live scheduler ticks; no time module dependency.
        self._memory_snapshot = None
        self._memory_hold_generation = 0
        self._memory_held = False
        self._memory_long_hold = False
        self._memory_modifier_used = False
        self._swallow_six_release = False

    def _performance_slot(self, pad_note):
        # Same red session rectangle as original working V3 (rows top-to-bottom).
        row = 7 - pad_note // 8
        col = pad_note % 8
        wrapper = self._session.scene(row).clip_slot(col)
        return wrapper._clip_slot

    def _valid_slot(self, slot):
        if slot is None or not slot.has_clip or getattr(slot, 'is_group_slot', False):
            return False
        track = slot.canonical_parent
        song = self.song()
        return track in song.tracks and not getattr(track, 'is_foldable', False)

    def _exclusive_launch_group(self, pad_notes):
        """Launch all selected clips; stop other tracks at the quantized boundary."""
        song = self.song()
        by_track = {}
        for note in pad_notes:
            slot = self._performance_slot(note)
            if self._valid_slot(slot):
                # Only one clip per track can play; last selection wins.
                by_track[slot.canonical_parent] = slot
        if not by_track:
            self.show_message('Exclusive: no valid clips selected')
            return False
        self._fill_job = None
        # Exclusive launch takes control away from A/B rotation.
        self._rotation_job = None
        self._rotation_fill_pending = None
        for track in tuple(song.tracks):
            if track not in by_track and not getattr(track, 'is_foldable', False):
                track.stop_all_clips(True)
        for slot in by_track.values():
            slot.fire(launch_quantization=song.clip_trigger_quantization)
        self.show_message('Exclusive launch queued: {} clips'.format(len(by_track)))
        return True

    def _mark_memory_long_hold(self, generation):
        # schedule_message(10) is approximately 1 second in Live.
        if (generation == self._memory_hold_generation
                and self._memory_held
                and not self._memory_modifier_used
                and not self._rotation_was_cancelled):
            self._memory_long_hold = True

    def _save_pattern_memory(self):
        # Store clip slots, not playing_slot_index integers.
        snapshot = {}
        for track in tuple(self.song().tracks):
            if getattr(track, 'is_foldable', False):
                continue
            index = track.playing_slot_index
            if index is not None and 0 <= index < len(track.clip_slots):
                slot = track.clip_slots[index]
                if slot.has_clip:
                    snapshot[track] = slot
        if not snapshot:
            self.show_message('Memory not saved: no clips playing')
            return
        self._memory_snapshot = snapshot
        self.show_message('Pattern saved: {} playing clips'.format(len(snapshot)))

    def _recall_pattern_memory(self):
        snapshot = self._memory_snapshot
        if snapshot is None:
            self.show_message('Memory empty: hold Shift + 6 to save')
            return
        self._rotation_job = None
        self._rotation_fill_pending = None
        self._fill_job = None
        quant = Live.Song.Quantization.q_bar
        restored = 0
        for track in tuple(self.song().tracks):
            if getattr(track, 'is_foldable', False):
                continue
            slot = snapshot.get(track)
            if slot is not None and slot in track.clip_slots and slot.has_clip:
                slot.fire(launch_quantization=quant)
                restored += 1
            else:
                track.stop_all_clips(True)
        self.show_message('Recall queued: {} clips next bar'.format(restored))

    def _start_rotation(self, pad_notes):
        """A = currently playing clips; B = pads selected with Shift + 6."""
        song = self.song()
        if not song.is_playing:
            self.show_message('Rotation: start Live transport first')
            return
        b = {}
        for note in pad_notes:
            slot = self._performance_slot(note)
            if self._valid_slot(slot):
                b[slot.canonical_parent] = slot
        if not b:
            self.show_message('Rotation: select occupied clip pads')
            return
        a = {}
        for track in tuple(song.tracks):
            if getattr(track, 'is_foldable', False):
                continue
            idx = int(track.playing_slot_index)
            if 0 <= idx < len(track.clip_slots):
                slot = track.clip_slots[idx]
                if slot.has_clip:
                    a[track] = slot
        if not a:
            self.show_message('Rotation: play Pattern A before selecting B')
            return
        bar = float(song.signature_numerator) * 4.0 / float(song.signature_denominator)
        if bar <= 0:
            return
        now = float(song.current_song_time)
        next_bar = (math.floor((now + 1e-6) / bar) + 1) * bar
        self._fill_job = None
        self._rotation_fill_pending = None
        self._rotation_job = {
            'a': a, 'b': b, 'tracks': tuple(set(a) | set(b)),
            'next': next_bar, 'bar': bar, 'step': 0, 'last_time': now
        }
        self.show_message('Rotation ON: 4 bars B / 4 bars A')

    def _rotation_tick(self):
        job = self._rotation_job
        if job is None:
            return
        song = self.song()
        if not song.is_playing:
            self._rotation_job = None
            return
        now = float(song.current_song_time)
        if now + .01 < job['last_time']:
            # Transport seek: cancel instead of launching at the wrong time.
            self._rotation_job = None
            return
        job['last_time'] = now
        # Send the launch shortly ahead of bar boundaries and use bar
        # quantization to ensure a coherent change. If the GUI callback is
        # late, launch immediately as a best effort.
        pending = self._rotation_fill_pending
        if pending is not None:
            # Do not launch the next A/B pattern while a fill is queued.
            if now < pending['at'] - .12:
                return
            self._rotation_fill_pending = None
            if pending['at'] <= now:
                quant = Live.Song.Quantization.q_no_q
            else:
                quant = Live.Song.Quantization.q_bar
            try:
                self._one_shot_fill_group(pending['pads'], quantization=quant,
                                          rotation_fill=True)
            except Exception as exc:
                self.log_message('APC rotation fill start error: {}'.format(exc))
                self._rotation_job = None
            return
        if job.get('paused_for_fill', False):
            return
        if now < job['next'] - .12:
            return
        target = job['b'] if job['step'] % 2 == 0 else job['a']
        late = now >= job['next']
        self._launch_rotation_pattern(job, target, late)
        job['step'] += 1
        job['next'] += 4 * job['bar']

    def _launch_rotation_pattern(self, job, target, late):
        song = self.song()
        quant = (Live.Song.Quantization.q_no_q if late
                 else Live.Song.Quantization.q_bar)
        for track in job['tracks']:
            if track not in song.tracks:
                continue
            slot = target.get(track)
            if slot is not None and slot.has_clip:
                slot.fire(launch_quantization=quant)
            else:
                track.stop_all_clips(not late)

    def _queue_rotation_fill(self, pad_notes):
        job = self._rotation_job
        if job is None:
            self._one_shot_fill_group(pad_notes)
            return
        # A fill is inserted after the CURRENT bar, not at the 4-bar
        # rotation boundary. The rotation is suspended until fill ends.
        song = self.song()
        now = float(song.current_song_time)
        bar = job['bar']
        at = (math.floor((now + 1e-6) / bar) + 1) * bar
        self._rotation_fill_pending = {'pads':tuple(pad_notes), 'at':at}
        job['paused_for_fill'] = True
        self.show_message('Rotation: fill queued for next bar')

    def _resume_rotation_after_fill(self, fill_job):
        job = self._rotation_job
        if job is None:
            # The player cancelled rotation while the fill was active.
            self._restore_previous(fill_job)
            return
        # Pick the opposite of the last active rotation pattern. The
        # existing step counter identifies the *next* pattern (A or B).
        song = self.song()
        now = float(song.current_song_time)
        bar = job['bar']
        target = job['b'] if job['step'] % 2 == 0 else job['a']
        # The fill finishes at a musical boundary. Prefer bar-quantized
        # launch so all clips return together, then allow a new 4-bar block.
        self._launch_rotation_pattern(job, target, late=False)
        # Stop fill-only tracks that are not part of either A/B pattern.
        # Otherwise the fill could keep looping indefinitely after its end.
        for track in fill_job['fill_tracks']:
            if track not in job['tracks'] and track in song.tracks:
                track.stop_all_clips(True)
        job['step'] += 1
        job['next'] = (math.floor((now + 1e-6) / bar) + 1) * bar + 4 * bar
        job['paused_for_fill'] = False
        job['last_time'] = now
        self.show_message('Rotation resumed after fill: next pattern queued')

    def _finish_rotation_modifier(self):
        selected = self._rotation_selected_notes
        self._rotation_selected_notes = []
        cancelled = self._rotation_was_cancelled
        self._rotation_was_cancelled = False
        self._memory_held = False
        used = self._memory_modifier_used
        self._memory_modifier_used = False
        long_hold = self._memory_long_hold
        self._memory_long_hold = False
        if cancelled:
            return
        try:
            if selected:
                self._start_rotation(selected)
            elif used:
                return
            elif long_hold:
                self._save_pattern_memory()
            else:
                self._recall_pattern_memory()
        except Exception as exc:
            self.log_message('APC rotation/memory command error: {}'.format(exc))
            self.show_message('APC command error; see Live Log.txt')

    @staticmethod
    def _fill_length_beats(clip, tempo):
        # Live's MIDI clip time and warped audio time use beats. Unwarped
        # audio times are in seconds; unsupported for precise musical returns.
        if getattr(clip, 'is_audio_clip', False) and not clip.warping:
            return None
        if clip.looping:
            length = float(clip.loop_end) - float(clip.loop_start)
        else:
            length = float(clip.end_marker) - float(clip.start_marker)
        return length if 0.0 < length < 2048.0 else None

    @staticmethod
    def _quantum_beats(song, quantization):
        # Live.Song.Quantization enum values documented for Live 12.
        bar = float(song.signature_numerator) * 4.0 / float(song.signature_denominator)
        return {0: 0, 1: bar*8, 2: bar*4, 3: bar*2, 4: bar,
                5: 2.0, 6: 4.0/3.0, 7: 1.0, 8: 2.0/3.0,
                9: .5, 10: 1.0/3.0, 11: .25, 12: 1.0/6.0,
                13: .125}.get(int(quantization), bar)

    @staticmethod
    def _time_grid_quantization(song, length, start_time, default_quant):
        # Use the user's Global Quantization when it fits the fill's ending.
        # When it doesn't, progressively select a finer note value so a
        # 2-beat fill doesn't wait for a 4-beat grid before returning.
        current = int(default_quant)
        choices = [current, 5, 7, 9, 11, 13]
        for choice in choices:
            quantum = PerformanceMixin._quantum_beats(song, choice)
            if quantum > 0 and quantum <= length + 1e-5:
                end = start_time + length
                # Quantized session clips start aligned to the global bar.
                # Test whether the desired END is also on the selected grid.
                if abs(end / quantum - round(end / quantum)) < .015:
                    return choice, quantum
        return 0, 0.0  # No grid fits: best-effort immediate restore.

    def _fill_snapshot(self):
        snapshot = []
        for track in tuple(self.song().tracks):
            if getattr(track, 'is_foldable', False):
                continue
            index = int(track.playing_slot_index)
            if index >= 0 and index < len(track.clip_slots):
                if track.clip_slots[index].has_clip:
                    snapshot.append((track, index))
        return snapshot

    def _one_shot_fill_group(self, pad_notes, quantization=None,
                             rotation_fill=False):
        song = self.song()
        # Only one clip per track can play. The last selected pad wins.
        by_track = {}
        for note in pad_notes:
            slot = self._performance_slot(note)
            if not self._valid_slot(slot):
                continue
            length = self._fill_length_beats(slot.clip, song.tempo)
            if length is None:
                self.show_message('Fill: clips must be warped audio or MIDI with valid length')
                return
            by_track[slot.canonical_parent] = (slot, length)
        if not by_track:
            self.show_message('Fill: no valid clips selected')
            return
        previous_job = self._fill_job
        snapshot = previous_job['snapshot'] if previous_job else self._fill_snapshot()
        self._fill_job = None
        quant = (song.clip_trigger_quantization if quantization is None
                 else quantization)
        # Stop all other tracks at the same quantization boundary.
        for track in tuple(song.tracks):
            if track not in by_track and not getattr(track, 'is_foldable', False):
                track.stop_all_clips(True)
        starts = []
        for track, (slot, length) in by_track.items():
            clip = slot.clip
            starts.append({'track':track, 'slot':slot, 'clip':clip,
                           'length':length, 'was_playing':bool(clip.is_playing),
                           'previous_start':float(clip.start_time) if clip.is_playing else None})
            slot.fire(launch_quantization=quant)
        self._fill_job = {'clips':starts, 'snapshot':tuple(snapshot),
                          'stage':'waiting', 'quant':quant,
                          'triggered_at':float(song.current_song_time),
                          'fill_tracks':tuple(by_track), 'end_at':None,
                          'restore_quant':None, 'rotation_fill':rotation_fill}
        self.show_message('Multi-fill queued: {} clips'.format(len(starts)))

    def _restore_previous(self, job):
        quant = job['restore_quant']
        restored_tracks = set()
        for track, index in job['snapshot']:
            if track not in self.song().tracks or index >= len(track.clip_slots):
                continue
            slot = track.clip_slots[index]
            if slot.has_clip:
                slot.fire(launch_quantization=quant)
                restored_tracks.add(track)
        for track in job['fill_tracks']:
            if track not in restored_tracks and track in self.song().tracks:
                track.stop_all_clips(bool(quant != 0))
        self.show_message('Multi-fill: returning to {} previous clips'.format(len(restored_tracks)))

    def _update_fill(self):
        job = self._fill_job
        if job is None:
            return
        song = self.song()
        if not song.is_playing:
            self._fill_job = None
            return
        now = float(song.current_song_time)
        if job['stage'] == 'waiting':
            starts = []
            for item in job['clips']:
                clip, track, slot = item['clip'], item['track'], item['slot']
                if not clip.is_playing or track.playing_slot_index < 0:
                    return
                if track.clip_slots[track.playing_slot_index] != slot:
                    return
                start = float(clip.start_time)
                if item['previous_start'] is not None and abs(start-item['previous_start']) < 1e-5:
                    # Live may not update start_time on a retrigger immediately.
                    if now - job['triggered_at'] < .2:
                        return
                    start = now
                if start < job['triggered_at'] - 1.0:
                    start = now
                starts.append(start)
            start = max(starts)
            length = max(item['length'] for item in job['clips'])
            job['end_at'] = start + length
            restore_quant, grid = self._time_grid_quantization(song, length, start, job['quant'])
            job['restore_quant'] = restore_quant
            job['grid'] = grid
            job['stage'] = 'playing'
        if job['stage'] == 'playing':
            end, grid = job['end_at'], job['grid']
            if grid > 0:
                lead = min(max(grid * .5, .22), grid * .9)
                ready = now >= end - lead
            else:
                ready = now >= end
            if ready:
                self._fill_job = None
                if job.get('rotation_fill', False):
                    self._resume_rotation_after_fill(job)
                else:
                    self._restore_previous(job)

    def update_display(self):
        super().update_display()
        try:
            self._update_fill()
            self._rotation_tick()
        except Exception as exc:
            self._fill_job = None
            self._rotation_job = None
            self.log_message('APC Fill/Rotation timing error: {}'.format(exc))

    def receive_midi(self, midi_bytes):
        if len(midi_bytes) == 3:
            status, note, velocity = midi_bytes
            kind = status & 0xF0
            channel = status & 0x0F
            if channel == 0 and kind in (0x80, 0x90):
                pressed = kind == 0x90 and velocity > 0
                if note == self.SHIFT_NOTE:
                    if pressed:
                        self._exclusive_shift_down = True
                        self._exclusive_selected_notes = []
                    else:
                        self._exclusive_shift_down = False
                        # Rotation and fill modifiers take precedence over exclusive launch.
                        if self._rotation_modifier_down:
                            self._rotation_modifier_down = False
                            self._rotation_modifier_consumed = False
                            self._swallow_six_release = True
                            self._finish_rotation_modifier()
                        elif self._fill_modifier_down:
                            self._fill_modifier_down = False
                            self._fill_modifier_consumed = True
                            selected = self._fill_selected_notes
                            self._fill_selected_notes = []
                            if selected:
                                self._queue_rotation_fill(selected)
                        else:
                            selected = self._exclusive_selected_notes
                            self._exclusive_selected_notes = []
                            if selected:
                                try:
                                    self._exclusive_launch_group(selected)
                                except Exception as exc:
                                    self.log_message('APC multi-exclusive error: {}'.format(exc))
                                    self.show_message('Multi-exclusive error; see Log.txt')
                    return super().receive_midi(midi_bytes)
                # Shift + 6 + 8 cancels rotation and MUST NOT reach stock
                # Stop All Clips on either note-on or note-off.
                if note == self.STOP_ALL_NOTE:
                    if pressed and self._exclusive_shift_down and self._rotation_modifier_down:
                        self._rotation_job = None
                        self._rotation_fill_pending = None
                        self._rotation_was_cancelled = True
                        self._memory_modifier_used = True
                        self._rotation_selected_notes = []
                        self._rotation_swallow_stop_release = True
                        self.show_message('Rotation OFF: current clips keep playing')
                        return
                    if not pressed and self._rotation_swallow_stop_release:
                        self._rotation_swallow_stop_release = False
                        return
                if note == self.ROTATION_MODIFIER_NOTE:
                    if pressed and self._exclusive_shift_down:
                        self._rotation_modifier_down = True
                        self._rotation_modifier_consumed = True
                        self._rotation_was_cancelled = False
                        self._rotation_selected_notes = []
                        self._memory_held = True
                        self._memory_long_hold = False
                        self._memory_modifier_used = False
                        self._memory_hold_generation += 1
                        self.schedule_message(10, self._mark_memory_long_hold,
                                              self._memory_hold_generation)
                        return
                    if not pressed and self._swallow_six_release:
                        self._swallow_six_release = False
                        return
                    if not pressed and self._rotation_modifier_consumed:
                        self._rotation_modifier_down = False
                        self._rotation_modifier_consumed = False
                        self._finish_rotation_modifier()
                        return
                if note == self.FILL_MODIFIER_NOTE:
                    # Consume Shift+Scene7, leaving stock scene-launch and
                    # scene LED behavior untouched for unshifted presses.
                    if pressed and self._exclusive_shift_down:
                        self._fill_modifier_down = True
                        self._fill_modifier_consumed = True
                        self._fill_selected_notes = []
                        return
                    if not pressed and self._fill_modifier_consumed:
                        self._fill_modifier_down = False
                        self._fill_modifier_consumed = False
                        selected = self._fill_selected_notes
                        self._fill_selected_notes = []
                        if selected:
                            try:
                                self._queue_rotation_fill(selected)
                            except Exception as exc:
                                self.log_message('APC Multi-fill error: {}'.format(exc))
                                self.show_message('Multi-fill error; see Log.txt')
                        return
                if 0 <= note < 64:
                    if not pressed and note in self._exclusive_consumed_pad_notes:
                        self._exclusive_consumed_pad_notes.discard(note)
                        return
                    if pressed and self._exclusive_shift_down:
                        self._exclusive_consumed_pad_notes.add(note)
                        try:
                            if self._rotation_modifier_down:
                                self._memory_modifier_used = True
                                if note not in self._rotation_selected_notes:
                                    self._rotation_selected_notes.append(note)
                                self.show_message('Rotation B: {} clips selected'.format(len(self._rotation_selected_notes)))
                            elif self._fill_modifier_down:
                                if note not in self._fill_selected_notes:
                                    self._fill_selected_notes.append(note)
                                self.show_message('Fill selection: {} clips'.format(len(self._fill_selected_notes)))
                            else:
                                if note not in self._exclusive_selected_notes:
                                    self._exclusive_selected_notes.append(note)
                                self.show_message('Exclusive selection: {} clips'.format(len(self._exclusive_selected_notes)))
                        except Exception as exc:
                            self._fill_job = None
                            self.log_message('APC Fill/Exclusive error: {}'.format(exc))
                            self.show_message('APC Fill/Exclusive error; see Live Log.txt')
                        return
                    if pressed and self._rotation_job is not None:
                        self._rotation_job = None
                        self._rotation_fill_pending = None
                        self.show_message('Rotation OFF: manual clip control')
                    if pressed and self._fill_job is not None:
                        # A normal pad means the performer took back control;
                        # don't surprise them with an automatic restore.
                        self._fill_job = None
                elif 82 <= note <= 89 and pressed:
                    if self._rotation_job is not None and not self._rotation_modifier_down:
                        self._rotation_job = None
                        self._rotation_fill_pending = None
                    if self._fill_job is not None:
                        self._fill_job = None
        return super().receive_midi(midi_bytes)


class APCMiniScopedOneShot(PerformanceMixin, StockAPCMini):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._performance_init()
        for row in range(self.SESSION_HEIGHT):
            scene = self._session.scene(row)
            scene._do_launch_scene = MethodType(_scoped_scene_launch, scene)


def create_instance(c_instance):
    return APCMiniScopedOneShot(c_instance)
